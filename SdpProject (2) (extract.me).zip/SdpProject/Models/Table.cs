﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SdpProject.Models
{
    public class Table
    {
        public int id { set; get; }

        public int number { set; get; }


    }
}

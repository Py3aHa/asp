﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using finalProject2.Data.Interfaces;
using finalProject2.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace finalProject2.Controllers
{
    public class DishesController : Controller
    {
        private readonly IDishCategory _dishCategories;
        private readonly IDishes _Dishes;

        public DishesController(IDishCategory categories, IDishes dishes)
        {
            _dishCategories = categories;
            _Dishes = dishes;
        }
        // GET: Dishes
        public IActionResult Index()
        {
            ListDishes dish = new ListDishes();
            dish.AllDishes = _Dishes.getAllDishes;
            return View(dish);
        }

    }
}
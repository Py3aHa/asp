﻿using finalProject2.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace finalProject2.ViewModels
{
    public class ListDishes
    {
        public IEnumerable<Dishes> AllDishes { set; get; }
    }
}

﻿using finalProject2.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace finalProject2.Data.Interfaces
{
    public interface IDishCategory
    {
        IEnumerable<DishCategory> AllCategories { get; }
    }
}

﻿using finalProject2.Data.Interfaces;
using finalProject2.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace finalProject2.Data.Mocks
{
    public class Categories : IDishCategory
    {
        public IEnumerable<DishCategory> AllCategories
        {
            get
            {
                return new List<DishCategory>
                {
                    new DishCategory {name = "National", description = "Naional kazakh dishes"},
                    new DishCategory {name = "Europe", description = "Europe dishes"},
                    new DishCategory {name = "Asian", description = "Asian dishes"}
                };
            }
        }
    }
}

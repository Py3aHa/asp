﻿using finalProject2.Data.Interfaces;
using finalProject2.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace finalProject2.Data.Mocks
{
    public class mockDishes : IDishes
    {
        private readonly IDishCategory _Category = new Categories();
        public IEnumerable<Dishes> getAllDishes {
            get
            {
                return new List<Dishes>
                {
                    new Dishes{ 
                        title = "frist dish", 
                        description = "Some desc", 
                        mass = 250, 
                        price = 2500,
                        img = "", 
                        category = _Category.AllCategories.First()
                    },
                    new Dishes{ 
                        title = "second dish",
                        description = "Some desc",
                        mass = 250,
                        price = 2500, 
                        img = "", 
                        category = _Category.AllCategories.Last()
                    }/*,
                    new Dishes{ title = "third dish", 
                        description = "Some desc", 
                        mass = 250,
                        price = 2500,
                        img = "", 
                        category = _Category.AllCategories.Single()
                    },
                    new Dishes{ title = "fourth dish",
                        description = "Some desc", 
                        mass = 250,
                        price = 2500, 
                        img = "", 
                        category = _Category.AllCategories.First()
                    },
                    new Dishes{ title = "fifth dish",
                        description = "Some desc",
                        mass = 250, 
                        price = 2500, 
                        img = "", 
                        category = _Category.AllCategories.Single()
                    }
                    */
                };
            }
        }


        public Dishes findDishByid(int id)
        {
            throw new NotImplementedException();
        }
    }
}
